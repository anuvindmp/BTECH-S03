#Python program to take an n-digit integer and print the digits of the number from left to right and right to left. 

number = input("Enter a number : ")

print("From right to left :", number[::-1])
print("from left to right :", number)
