#GRADING
marks = float(input("Enter your computer science marks : "))
if marks>100 :
    print ("Invalid Marks")
elif marks >=90 :
    print("A grade")
elif marks >=80 :
    print("B grade")
elif marks >=70 :
    print("C grade")
elif marks >=60 :
    print("D grade")
else:
    print("F grade")